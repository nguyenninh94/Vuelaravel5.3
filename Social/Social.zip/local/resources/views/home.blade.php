@extends('layouts.app')

@section('content')
   <post></post>

   <feed></feed>
@endsection
