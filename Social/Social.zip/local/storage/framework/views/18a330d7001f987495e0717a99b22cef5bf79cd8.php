<?php $__env->startSection('content'); ?>
    
    <div class="container">
    	<div class="col-lg-4">
    		<div class="panel panel-default">
    			<div class="panel-heading text-center">
    				<?php echo e($user->name); ?>

    			</div>

    			<div class="panel panel-body text-center">
    				<img src="<?php echo e($user->avatar); ?>" width="140px" height="140px" style="border-radius:50%;" alt="">
                    <p>
                        <?php echo e($user->profile->location); ?>

                    </p>
    				<p>
    					<?php if(Auth::id() == $user->id): ?>
                           <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-lg btn-info">Update Your Profile</a>
    					<?php endif; ?>
    				</p>
    			</div>
    		</div>
            
            <?php if(Auth::id() !== $user->id): ?>
            <div class="panel panel-default">
                <div class="body" id="app">
                    <friend :profile_user_id="<?php echo e($user->id); ?>"></friend>
                </div>
            </div>
            <?php endif; ?>

            <div class="panel panel-default">
                <div class="panel-heading text-center">
                    About me
                </div>

                <div class="panel panel-body text-center">
                     <?php echo e($user->profile->about); ?>

                </div>
            </div>
    	</div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>